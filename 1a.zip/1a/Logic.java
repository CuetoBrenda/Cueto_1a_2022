
/**
 * @author Jacqueline
 */

public class Logic {

    public Logic() {
    }

    private int n;
    private String data;
    private String[] arrData;
    private double media;
    public double desv;

    public void logic1a() {
        
        Input myInput = new Input();
        Output myOut = new Output();
        
		Data myData = new Data();
		Media myMedia = new Media();
		DesvEst myDesv = new DesvEst();

        data = myInput.readData("C:\\Users\\Jacqueline\\OneDrive - Universidad Veracruzana\\Jacque\\8vo Semestre\\Aspectos Humanos ISW\\Clase\\Proyecto 1a\\Code\\Codeset3.txt");
        System.out.println("data :  " + data);

		arrData = myData.saveData(data);
        n = arrData.length;
        System.out.println("n :  " + n);

        media = myMedia.getMedia(arrData, n);
        System.out.println("media :  " + media);

		desv = myDesv.getDesvEstd(arrData, media, n);
        System.out.println("desv std :  " + desv);

        myOut.writeData("C:\\Users\\Jacqueline\\OneDrive - Universidad Veracruzana\\Jacque\\8vo Semestre\\Aspectos Humanos ISW\\Clase\\Proyecto 1a\\Code\\out1.txt", "Media = " + media + " Desv. = " + desv);

    }

}